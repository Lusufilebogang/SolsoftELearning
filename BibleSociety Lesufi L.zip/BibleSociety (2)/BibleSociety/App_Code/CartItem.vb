﻿Imports Microsoft.VisualBasic

' The CartItem Class
' Basically a structure for holding item data
Public Class CartItem
	Implements IEquatable(Of CartItem)

#Region "Properties"

	' A place to store the quantity in the cart
	Private _quantity As Integer
	Public Property Quantity() As Integer
		Get
			Return _quantity
		End Get
		Set(ByVal value As Integer)
			_quantity = value
		End Set
	End Property

    Private _BookId As Integer
    Public Property BookId() As Integer
        Get
            Return _BookId
        End Get
        Set(ByVal value As Integer)
            ' To ensure that the Prod object will be re-created
            _BookId = value
        End Set
    End Property

    Private _name As String
    Public Property name() As String
        Get
            Return _name
        End Get
        Set(ByVal value As String)
            _name = value
        End Set
    End Property

    Private _unitprice As Decimal
    Public Property UnitPrice() As Decimal
        Get
            Return _unitprice
        End Get
        Set(ByVal value As Decimal)
            _unitprice = value
        End Set
    End Property

	Private _prod As Product = Nothing
	Public ReadOnly Property Prod() As Product
		Get
			' Lazy initialization - the object won't be created until it is needed
			If _prod Is Nothing Then
                _prod = New Product(BookId, name, UnitPrice)
			End If
			Return _prod
		End Get
	End Property




	Public ReadOnly Property TotalPrice() As Decimal
		Get
			Return UnitPrice * Quantity
		End Get
	End Property

#End Region

	' CartItem constructor just needs a productId
    Public Sub New(ByVal productId As Integer, ByVal nme As String, ByVal prce As Decimal)
        Me.BookId = productId
        Me.name = nme
        Me.UnitPrice = prce
    End Sub

	' Equals() - Needed to implement the IEquatable interface
	' Tests whether or not this item is equal to the parameter
	' This method is called by the Contains() method in the List class
	' We used this Contains() method in the ShoppingCart AddItem() method
	Public Overloads Function Equals(ByVal item As CartItem) As Boolean Implements IEquatable(Of CartItem).Equals
        Return item.BookId = Me.BookId
	End Function

End Class
