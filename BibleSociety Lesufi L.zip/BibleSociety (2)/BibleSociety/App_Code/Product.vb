﻿Imports Microsoft.VisualBasic

' The Product class
' This is just to simulate some way of accessing data about  our products
Public Class Product

#Region "Properties"

    Private _Bookid As Integer
    Public Property BookId() As Integer
        Get
            Return _Bookid
        End Get
        Set(ByVal value As Integer)
            _Bookid = value
        End Set
    End Property

	Private _price As Decimal
	Public Property Price() As Decimal
		Get
			Return _price
		End Get
		Set(ByVal value As Decimal)
			_price = value
		End Set
	End Property

    Private _name As String
    Public Property name() As String
        Get
            Return _name
        End Get
        Set(ByVal value As String)
            _name = value
        End Set
    End Property

#End Region

    Public Sub New(ByVal theid As Integer, ByVal thename As String, ByVal theprice As Decimal)
        BookId = theid
        name = thename
        Price = theprice
    End Sub


End Class
