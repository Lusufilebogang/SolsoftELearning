﻿
Partial Class reset
    Inherits System.Web.UI.Page

End Class
