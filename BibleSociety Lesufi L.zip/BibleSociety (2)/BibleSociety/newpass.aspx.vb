﻿
Partial Class newpass
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Protected Sub btnlogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnlogin.Click
        Dim eml As String
        eml = Request.QueryString("email")
        Try
            Dim qry As String = "UPDATE Customer SET Password = @pass WHERE EmailAddress = @eml"
            Dim sqlcmd As New SqlCommand(qry, cn)
            sqlcmd.Parameters.Add("@pass", SqlDbType.NVarChar).Value = txtpass1.Text
            sqlcmd.Parameters.Add("@eml", SqlDbType.NVarChar).Value = eml
            cn.Open()
            sqlcmd.ExecuteScalar()
            sqlcmd.Dispose()
            cn.Close()
            lblmsg.Text = "Your New Password Has Been Updated"
        Catch ex As Exception
            cn.Close()
            lblmsg.Text = "Password Not Updated" & ex.Message
        End Try
        Response.Redirect("Books.aspx")
    End Sub
End Class
