﻿
Partial Class customer_Prologue
    Inherits System.Web.UI.Page

End Class
