﻿
Partial Class customer_Invoice
    Inherits System.Web.UI.Page
    Private cart As ShoppingCart
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Dim DataView As DataRowView

    Private Property Mid As DataView

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            lblorderno.Text = Request.QueryString("orderno")
            lblname.Text = Session("username")
            lblname0.Text = Session("username")
            txtref.Text = lblorderno.Text
            Try
                Dim qry As String = " Select * FROM Customer WHERE FirstName = @FirstName"
                Dim cmd As New SqlCommand(qry, cn)
                cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar).Value = lblname.Text
                Dim rdr As SqlDataReader
                cn.Open()
                rdr = cmd.ExecuteReader
                While rdr.Read
                    lblcustno.Text = rdr("CustomerID")
                    txtname.Text = rdr("FirstName")
                    txtaddress.Text = rdr("Address")
                End While
                cn.Close()
                cmd.Dispose()
            Catch ex As Exception
                cn.Close()
                lblcustno.Text = ex.Message
            End Try
            BindData()
            Dim amt As Decimal = ShoppingCart.Instance.GetSubTotal().ToString("C")
            txtammount.Text = amt.ToString.Substring(0)
        End If
    End Sub
    Protected Sub BindData()
        ' Let's give the data to the GridView and let it work!
        ' The GridView will take our cart items one by one and use the properties
        ' that we declared as column names (DataFields)
        gvShoppingCart.DataSource = ShoppingCart.Instance.Items
        gvShoppingCart.DataBind()
    End Sub

    Protected Sub gvShoppingCart_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gvShoppingCart.RowDataBound
        ' If we are binding the footer row, let's add in our total
        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(3).Text = "Total: " & ShoppingCart.Instance.GetSubTotal().ToString("C")
        End If
    End Sub

    ' This is the method that responds to the Remove button's click event
    Protected Sub gvShoppingCart_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs) Handles gvShoppingCart.RowCommand
        If e.CommandName = "Remove" Then
            Dim productId = Convert.ToInt32(e.CommandArgument)
            Dim name = Convert.ToString(e.CommandArgument)
            Dim prce = Convert.ToDecimal(e.CommandArgument)
            ShoppingCart.Instance.RemoveItem(productId, name, prce)
        End If

        ' We now have to re-setup the data so that the GridView doesn't keep displaying the old data
        BindData()
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnTransaction.Click
        Try
            Dim qry As String = "INSERT INTO transactiontable ( AccountNo , InvoiceNo ,FullName , BankName , Amount , Address ) VALUES" & _
                                        " ( @AccountNo , @InvoiceNo , @FullName , @BankName , @Amount , @Address )  "
            Dim sqlcmd As New SqlCommand(qry, cn)
            sqlcmd.Parameters.Add("@FullName", SqlDbType.NVarChar).Value = txtname.Text
            sqlcmd.Parameters.Add("@AccountNo", SqlDbType.Int).Value = txtaccno.Text
            sqlcmd.Parameters.Add("@InvoiceNo", SqlDbType.Int).Value = lblorderno.Text
            sqlcmd.Parameters.Add("@Address", SqlDbType.NVarChar).Value = txtaddress.Text
            sqlcmd.Parameters.Add("@Amount", SqlDbType.NVarChar).Value = txtammount.Text
            sqlcmd.Parameters.Add("@BankName", SqlDbType.NVarChar).Value = DropDownList1.SelectedValue
            cn.Open()
            sqlcmd.ExecuteScalar()
            sqlcmd.Dispose()
            cn.Close()
            clearcontrols()
            lblmsg.Text = "Your information was submitted sucessfully"
            Response.Redirect("Invoice.aspx")
        Catch ex As Exception

            lblmsg.Text = " Not Submitted " & ex.Message
            cn.Close()
        End Try
        loadCart()
    End Sub

    Public Sub clearcontrols()
        txtname.Text = ""
        txtaccno.Text = ""
        lblorderno.Text = ""
        txtaddress.Text = ""
        txtammount.Text = ""
    End Sub

    Public Sub loadCart()
        Dim dv As New DataView
        dv = New DataView()
        Dim dr As DataRowView = dv(CInt(0))
        Dim bookid As String = dr("BookID")
        Dim name As String = dr("BookName")
        Dim Price As Decimal = dr("Price")

        ShoppingCart.Instance.AddItem(bookid, name)
        ' Redirect the user to view their shopping cart

        Dim Book As String
        Book = Request.QueryString("Book")
        Response.Redirect("invoice.aspx?Book=" & bookid)
    End Sub

    Private Function dv() As DataRowView
        Throw New NotImplementedException
    End Function

End Class
