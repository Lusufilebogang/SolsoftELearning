﻿
Partial Class cust_Account
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            lblname.Text = Session("username")
            Try
                Dim qry As String = " Select * FROM Customer WHERE EmailAddress = @emailaddress"
                Dim cmd As New SqlCommand(qry, cn)
                cmd.Parameters.Add("@emailaddress", SqlDbType.NVarChar).Value = lblname.Text
                Dim rdr As SqlDataReader
                cn.Open()
                rdr = cmd.ExecuteReader
                While rdr.Read
                    lblcustno.Text = rdr("CustomerID")
                    txtfname.Text = rdr("FirstName")
                    txtlname.Text = rdr("LastName")
                    txtcellno.Text = rdr("CellNo")
                    txtaddr.Text = rdr("Address")
                    txtintr.Text = rdr("Interests")
                    txtpass.Text = rdr("Password")
                End While
                cn.Close()
                cmd.Dispose()
            Catch ex As Exception
                cn.Close()

            End Try
        End If
    End Sub

    Protected Sub btnupdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Try
            Dim sqlquery As String = " UPDATE Customer " & _
                                    "SET FirstName =@custfnme" & _
                                    "  , LastName =@custlnme " & _
                                    " , Password = @custpass" & _
                                    " , CellNo = @cntno" & _
                                    " , Address = @resadd" & _
                                    " , Interests = @intr" & _
                                    " WHERE CustomerID = @custID"
            Dim sqlcmd As New SqlCommand(sqlquery, cn)
            sqlcmd.Parameters.Add("@CustID", SqlDbType.Int).Value = lblcustno.Text
            sqlcmd.Parameters.Add("@custfnme", SqlDbType.NVarChar).Value = txtfname.Text
            sqlcmd.Parameters.Add("@custlnme", SqlDbType.NVarChar).Value = txtlname.Text
            sqlcmd.Parameters.Add("@custpass", SqlDbType.NVarChar).Value = txtpass.Text
            sqlcmd.Parameters.Add("@cntno", SqlDbType.NVarChar).Value = txtcellno.Text
            sqlcmd.Parameters.Add("@intr", SqlDbType.NVarChar).Value = txtintr.Text
            sqlcmd.Parameters.Add("@resadd", SqlDbType.NVarChar).Value = txtaddr.Text
            cn.Open()
            sqlcmd.ExecuteScalar()
            sqlcmd.Dispose()
            cn.Close()
            lblmessage.Text = " Your Information Was Successfully Updated "
        Catch ex As Exception
            cn.Close()
            lblmessage.Text = " Information Not Changed " & ex.Message
        End Try
    End Sub
End Class
