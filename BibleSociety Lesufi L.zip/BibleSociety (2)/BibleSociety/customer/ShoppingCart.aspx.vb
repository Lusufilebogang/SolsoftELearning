﻿
Partial Class cust_ShoppingCart
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Dim orderno As Integer
    

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            lblname.Text = Session("username")
            Try
                Dim qry As String = " Select * FROM Customer WHERE FirstName = @FirstName"
                Dim cmd As New SqlCommand(qry, cn)
                cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar).Value = lblname.Text
                Dim rdr As SqlDataReader
                cn.Open()
                rdr = cmd.ExecuteReader
                While rdr.Read
                    lblcustno.Text = rdr("CustomerID")
                End While
                cn.Close()
                cmd.Dispose()
            Catch ex As Exception
                cn.Close()
                lblcustno.Text = ex.Message
            End Try
            BindData()
        End If
    End Sub

    Protected Sub btnContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnContinue.Click
            Response.Redirect("Product.aspx")  
    End Sub
    Protected Sub btnCheckOut_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCheckOut.Click
        Try
            createneworder()
            Try
                selectorder()
                Try
                    Response.Redirect("IPay.aspx?orderno=" & orderno)
                Catch ex As Exception
                    lblmsg.Text = "cannot insert order items " & ex.Message
                End Try
            Catch ex As Exception
                lblmsg.Text = "cannot select order " & ex.Message
            End Try
        Catch ex As Exception
            lblmsg.Text = "cannot create order " & ex.Message
        End Try

        'Dim dv As DataView

        'Dim dr As DataRowView = dv(0)
        Dim dv As New DataView
        dv = dv(0).DataView
        Dim dr As DataRowView = dv(1)
        Dim bookid As String = dr("BookID")
        Dim name As String = dr("BookName")
        Dim Price As Decimal = dr("Price")

        ShoppingCart.Instance.AddItem(bookid, name, Price)

        ' Redirect the user to view their shopping cart

        Dim Book As String
        Book = Request.QueryString("Book")
        Response.Redirect("IPay.aspx?Book=" & bookid)

    End Sub
    Protected Sub BindData()
        ' Let's give the data to the GridView and let it work!
        ' The GridView will take our cart items one by one and use the properties
        ' that we declared as column names (DataFields)
        gvShoppingCart.DataSource = ShoppingCart.Instance.Items
        gvShoppingCart.DataBind()
    End Sub

    Protected Sub gvShoppingCart_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gvShoppingCart.RowDataBound
        ' If we are binding the footer row, let's add in our total
        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(3).Text = "Total: " & ShoppingCart.Instance.GetSubTotal().ToString("C")

        End If
    End Sub

    ' This is the method that responds to the Remove button's click event
    Protected Sub gvShoppingCart_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs) Handles gvShoppingCart.RowCommand
        If e.CommandName = "Remove" Then
            Dim productId = Convert.ToInt32(e.CommandArgument)
            Dim name = Convert.ToString(e.CommandArgument)
            Dim prce = Convert.ToDecimal(e.CommandArgument)
            ShoppingCart.Instance.RemoveItem(productId, name, prce)
        End If

        ' We now have to re-setup the data so that the GridView doesn't keep displaying the old data
        BindData()
    End Sub

    Protected Sub btnUpdateCart_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpdateCart.Click
        For Each row As GridViewRow In gvShoppingCart.Rows
            If row.RowType = DataControlRowType.DataRow Then
                ' We'll use a try catch block in case something other than a number is typed in. If so, we'll just ignore it.
                Try
                    ' Get the productId from the GridView's datakeys
                    Dim name = Convert.ToString(gvShoppingCart.DataKeys(row.RowIndex).Value)
                    Dim prce = Convert.ToString(gvShoppingCart.DataKeys(row.RowIndex).Value)
                    Dim productId = Convert.ToInt32(gvShoppingCart.DataKeys(row.RowIndex).Value)
                    ' Find the quantity TextBox and retrieve the value
                    Dim quantity = Integer.Parse(CType(row.Cells(1).FindControl("txtQuantity"), TextBox).Text)
                    ShoppingCart.Instance.SetItemQuantity(productId, quantity, name, prce)
                Catch ex As FormatException
                End Try
            End If
        Next

        BindData()
    End Sub

    Public Sub createneworder()
        Dim qry As String = " INSERT INTO OrderDetails (CustomerID , OrderDate) VALUES " _
                            & "(@custid , @orderdate) "
        Dim sqlcmd As New SqlCommand(qry, cn)
        sqlcmd.Parameters.Add("@custid", SqlDbType.Int).Value = CInt(lblcustno.Text)
        sqlcmd.Parameters.Add("@orderdate", SqlDbType.Date).Value = Date.Today
        cn.Open()
        sqlcmd.ExecuteScalar()
        sqlcmd.Dispose()
        cn.Close()
    End Sub

    Public Sub selectorder()
            Dim qry As String = " Select MAX(OrderID)  FROM OrderDetails "
            Dim cmd As New SqlCommand(qry, cn)
            Dim rdr As SqlDataReader
            cn.Open()
            rdr = cmd.ExecuteReader
            While rdr.Read
                orderno = rdr.GetInt32(0)
            End While
            cn.Close()
            cmd.Dispose()
    End Sub

    Public Sub insertorderitems()
        For i As Integer = 0 To gvShoppingCart.Rows.Count - 1
            Try
                Dim rowes As GridViewRow
                rowes = gvShoppingCart.Rows(i)
                Dim qry As String = " INSERT INTO OrderedItems (OrderID , BookID , BookName , Quantity , Price ) VALUES " _
                        & " (@OrderID , @BkID , @BkName , @Quant , @Price )"
                Dim sqlcmd As New SqlCommand(qry, cn)

                Dim name As String = gvShoppingCart.Rows(i).Cells(1).Text
                Dim prce As Decimal = gvShoppingCart.Rows(i).Cells(3).Text
                Dim productId As Integer = gvShoppingCart.Rows(i).Cells(0).Text
                ' Find the quantity TextBox and retrieve the value
                Dim quantity = Integer.Parse(CType(rowes.Cells(1).FindControl("txtQuantity"), TextBox).Text)
                sqlcmd.Parameters.Add("@BkID", SqlDbType.Int).Value = productId
                sqlcmd.Parameters.Add("@OrderID", SqlDbType.Int).Value = orderno
                sqlcmd.Parameters.Add("@Quant", SqlDbType.Int).Value = quantity
                sqlcmd.Parameters.Add("@BkName", SqlDbType.NVarChar).Value = name
                sqlcmd.Parameters.Add("@Price", SqlDbType.Money).Value = prce
                cn.Open()
                sqlcmd.ExecuteScalar()
                sqlcmd.Dispose()
                cn.Close()
            Catch ex As FormatException
            End Try
        Next i
    End Sub
End Class
