﻿
Partial Class customer_Invoice
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            selectorder()
            lblname.Text = Session("username")
            lblname0.Text = Session("username")
            Try
                Dim qry As String = " Select * FROM Customer WHERE FirstName = @FirstName"
                Dim cmd As New SqlCommand(qry, cn)
                cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar).Value = lblname.Text
                Dim rdr As SqlDataReader
                cn.Open()
                rdr = cmd.ExecuteReader
                While rdr.Read
                    lblcustno.Text = rdr("CustomerID")

                End While
                cn.Close()
                cmd.Dispose()
            Catch ex As Exception
                cn.Close()
                lblcustno.Text = ex.Message
            End Try
            BindData()
        End If
    End Sub
   

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Session("ctrl") = Panel1
        ClientScript.RegisterStartupScript(Me.GetType(), "onclick", "<script language=javascript>window.open('Print.aspx','PrintMe','height=340px,width=680px,scrollbars=1');</script>")
    End Sub

    Protected Sub BindData()
        ' Let's give the data to the GridView and let it work!
        ' The GridView will take our cart items one by one and use the properties
        ' that we declared as column names (DataFields)
        gvShoppingCart.DataSource = ShoppingCart.Instance.Items
        gvShoppingCart.DataBind()
    End Sub

    Protected Sub gvShoppingCart_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs) Handles gvShoppingCart.RowDataBound
        ' If we are binding the footer row, let's add in our total
        If e.Row.RowType = DataControlRowType.Footer Then
            e.Row.Cells(3).Text = "Total: " & ShoppingCart.Instance.GetSubTotal().ToString("C")
        End If
    End Sub

    ' This is the method that responds to the Remove button's click event
    Protected Sub gvShoppingCart_RowCommand(ByVal sender As Object, ByVal e As GridViewCommandEventArgs) Handles gvShoppingCart.RowCommand
        If e.CommandName = "Remove" Then
            Dim productId = Convert.ToInt32(e.CommandArgument)
            Dim name = Convert.ToString(e.CommandArgument)
            Dim prce = Convert.ToDecimal(e.CommandArgument)
            ShoppingCart.Instance.RemoveItem(productId, name, prce)
        End If

        ' We now have to re-setup the data so that the GridView doesn't keep displaying the old data
        BindData()
    End Sub

    Public Sub selectorder()
        Dim qry As String = " Select MAX(OrderID)  FROM OrderDetails "
        Dim cmd As New SqlCommand(qry, cn)
        Dim rdr As SqlDataReader
        cn.Open()
        rdr = cmd.ExecuteReader
        While rdr.Read
            lblorderno.Text = rdr.GetInt32(0)
        End While
        cn.Close()
        cmd.Dispose()
    End Sub
    
End Class
