﻿
Partial Class cust_productfulldetails
    Inherits System.Web.UI.Page

    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            lblname.Text = Session("username")
            Try
                Dim qry As String = " Select * FROM Customer WHERE FirstName = @FirstName"
                Dim cmd As New SqlCommand(qry, cn)
                cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar).Value = lblname.Text
                Dim rdr As SqlDataReader
                cn.Open()
                rdr = cmd.ExecuteReader
                While rdr.Read
                    lblcustno.Text = rdr("CustomerID")
                End While
                cn.Close()
                cmd.Dispose()
            Catch ex As Exception
                cn.Close()
                lblcustno.Text = ex.Message
            End Try
        End If
    End Sub

    Protected Sub btnadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Dim dv As DataView
        dv = SqlDataSource1.Select(DataSourceSelectArguments.Empty)
        Dim dr As DataRowView = dv(0)
        Dim bookid As String = dr("BookID")
        Dim name As String = dr("BookName")
        Dim Price As Decimal = dr("Price")

        ShoppingCart.Instance.AddItem(bookid, name, Price)

        ' Redirect the user to view their shopping cart

        Dim Book As String
        Book = Request.QueryString("Book")
        Response.Redirect("ShoppingCart.aspx?Book=" & BookID)
        'lblmsg.text = ID & name & Price
    End Sub

    Protected Sub btnbck_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnbck.Click
        Response.Redirect("product.aspx")
    End Sub

   
End Class
