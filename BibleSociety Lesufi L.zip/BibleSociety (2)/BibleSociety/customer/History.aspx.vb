﻿
Partial Class cust_History
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            lblname.Text = Session("username")
            Try
                Dim qry As String = " Select * FROM Customer WHERE FirstName = @FirstName"
                Dim cmd As New SqlCommand(qry, cn)
                cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar).Value = lblname.Text
                Dim rdr As SqlDataReader
                cn.Open()
                rdr = cmd.ExecuteReader
                While rdr.Read
                    lblcustno.Text = rdr("CustomerID")
                End While
                cn.Close()
                cmd.Dispose()
            Catch ex As Exception
                cn.Close()
                lblcustno.Text = ex.Message
            End Try
        End If
    End Sub
End Class
