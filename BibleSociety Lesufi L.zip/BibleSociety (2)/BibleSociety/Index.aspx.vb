﻿
Partial Class Index
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ShoppingCart.Instance.Items.Clear()
    End Sub
End Class
