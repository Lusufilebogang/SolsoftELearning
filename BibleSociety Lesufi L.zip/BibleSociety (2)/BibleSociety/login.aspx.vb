﻿
Partial Class login
    Inherits System.Web.UI.Page

    Protected Sub btnfrgot_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnfrgot.Click
        Response.Redirect("reset.aspx")
    End Sub

    
End Class
