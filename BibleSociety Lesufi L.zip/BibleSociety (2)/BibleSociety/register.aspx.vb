﻿
Partial Class register
    Inherits System.Web.UI.Page
    Dim Constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(Constr)

    Protected Sub btnRegister_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegister.Click
        Try
            Dim qry As String = "INSERT INTO Customer (FirstName , LastName , CellNo , EmailAddress , Address , Interests, Password ) VALUES" & _
                                        " (@FName , @LName , @CellNo , @EmAdd , @Addr , @Inter, @Pass )  "
            Dim sqlcmd As New SqlCommand(qry, cn)
            sqlcmd.Parameters.Add("@fname", SqlDbType.NVarChar).Value = txtfnme.Text
            sqlcmd.Parameters.Add("@LName", SqlDbType.NVarChar).Value = txtlnme.Text
            sqlcmd.Parameters.Add("@CellNo", SqlDbType.NVarChar).Value = txtcellno.Text
            sqlcmd.Parameters.Add("@EmAdd", SqlDbType.NVarChar).Value = txteml.Text
            sqlcmd.Parameters.Add("@Addr", SqlDbType.NVarChar).Value = txtaddr.Text
            sqlcmd.Parameters.Add("@Inter", SqlDbType.NVarChar).Value = txtintrst.Text
            sqlcmd.Parameters.Add("@Pass", SqlDbType.NVarChar).Value = txtpass2.Text
            cn.Open()
            sqlcmd.ExecuteScalar()
            sqlcmd.Dispose()
            cn.Close()
            lblmsg.Text = "You have registered successfully you can log in now"
            Response.Redirect("Login.aspx")

        Catch ex As Exception
            lblmsg.Text = "Not registered " & ex.Message
            cn.Close()
        End Try

    End Sub
End Class
