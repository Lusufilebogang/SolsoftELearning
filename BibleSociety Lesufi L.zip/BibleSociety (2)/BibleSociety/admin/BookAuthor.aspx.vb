﻿
Partial Class admin_BookAuthor
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)

    Protected Sub btnadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            Dim qry As String = "INSERT INTO BookAuthor (BookID , AuthorID , BookName ) VALUES (@BID, @AID , @BName)"
            Dim sqlcmd As New SqlCommand(qry, cn)
            sqlcmd.Parameters.Add("@BID", SqlDbType.Int).Value = DDLBook.SelectedValue
            sqlcmd.Parameters.Add("@AID", SqlDbType.Int).Value = DDLAuthor.SelectedValue
            sqlcmd.Parameters.Add("@BName", SqlDbType.NVarChar).Value = DDLBook.SelectedItem.Text
            cn.Open()
            sqlcmd.ExecuteScalar()
            sqlcmd.Dispose()
            cn.Close()
            lblmsg.text = "Author added to book"
        Catch ex As Exception
            cn.Close()
            lblmsg.Text = "author not added  "
        End Try
    End Sub
End Class
