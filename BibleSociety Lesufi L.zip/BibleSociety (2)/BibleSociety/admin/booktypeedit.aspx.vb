﻿
Partial Class admin_booktypeedit
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        txtname.Text = GridView1.SelectedRow.Cells(2).Text
        txtdesc.Text = GridView1.SelectedRow.Cells(3).Text
    End Sub
    Protected Sub btnadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            Dim qry As String = "UPDATE BookType SET TypeName = @TName , Description = @Descr " _
                                 & " WHERE TypeID = @TID"
            Dim sqlcmd As New SqlCommand(qry, cn)
            sqlcmd.Parameters.Add("@TID", SqlDbType.Char).Value = GridView1.SelectedRow.Cells(1).Text
            sqlcmd.Parameters.Add("@TName", SqlDbType.NVarChar).Value = txtname.Text
            sqlcmd.Parameters.Add("@Descr", SqlDbType.NVarChar).Value = txtdesc.Text
            cn.Open()
            sqlcmd.ExecuteScalar()
            sqlcmd.Dispose()
            cn.Close()
            lblmsg.Text = "Record Updated"
            GridView1.DataBind()
            clearcontrols()
        Catch ex As Exception
            cn.Close()
            lblmsg.Text = "Not Updated " & ex.Message
        End Try
    End Sub
    Public Sub clearcontrols()
        txtname.Text = ""
        txtdesc.Text = ""

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
    End Sub
End Class