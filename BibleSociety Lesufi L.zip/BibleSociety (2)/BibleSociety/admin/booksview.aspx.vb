﻿
Partial Class admin_booksview
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblnbooks.Text = GridView1.Rows.Count
    End Sub
End Class
