﻿
Partial Class admin_SalesPerson
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Protected Sub btnadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadd.Click

        Try
            Dim qry As String = "INSERT INTO SalesPerson (FIrstName , LastName , CellNo , EmailAddress , Address ,Location ) VALUES " & _
                                       "(@FName , @LName , @CellNo , @EmlAddr , @Addr , @Loc)"
            Dim sqlcmd As New SqlCommand(qry, cn)
            sqlcmd.Parameters.Add("@FName", SqlDbType.NVarChar).Value = txtfname.Text
            sqlcmd.Parameters.Add("@LName", SqlDbType.NVarChar).Value = txtlname.Text
            sqlcmd.Parameters.Add("@CellNo", SqlDbType.NVarChar).Value = txtcell.Text
            sqlcmd.Parameters.Add("@EmlAddr", SqlDbType.NVarChar).Value = txteml.Text
            sqlcmd.Parameters.Add("@Addr", SqlDbType.NVarChar).Value = txtaddr.Text
            sqlcmd.Parameters.Add("@Loc", SqlDbType.NVarChar).Value = txtlocation.Text
            cn.Open()
            sqlcmd.ExecuteScalar()
            sqlcmd.Dispose()
            cn.Close()
            lblmsg.Text = "SalesPerson Added Successfully"
            clearcontrols()
        Catch ex As Exception
            cn.Close()
            lblmsg.Text = "Not Added  " & ex.Message
        End Try



    End Sub

    Public Sub clearcontrols()
        txtfname.Text = ""
        txtlname.Text = ""
        txtcell.Text = ""
        txteml.Text = ""
        txtaddr.Text = ""
        txtlocation.Text = ""
    End Sub
End Class
