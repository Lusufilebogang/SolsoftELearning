﻿
Partial Class admin_Publisher
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Protected Sub btnadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            Dim qry As String = "INSERT INTO Publisher (PublisherName, ContactNo ,Address ,Website) " _
                                & "VALUES (@PubName, @ContNo ,@Addr ,@Web)"
            Dim sqlcmd As New SqlCommand(qry, cn)
            sqlcmd.Parameters.Add("@PubName", SqlDbType.NVarChar).Value = txtname.Text
            sqlcmd.Parameters.Add("@ContNo", SqlDbType.NVarChar).Value = txtcontact.Text
            sqlcmd.Parameters.Add("@Addr", SqlDbType.NVarChar).Value = txtaddr.Text
            sqlcmd.Parameters.Add("@Web", SqlDbType.NVarChar).Value = txtweb.Text
            cn.Open()
            sqlcmd.ExecuteScalar()
            sqlcmd.Dispose()
            cn.Close()
            clearcontrols()
            lblmsg.Text = " Publisher Added Successfully "
        Catch ex As Exception
            cn.Close()
            lblmsg.Text = " Not Added  " & ex.Message
        End Try
    End Sub

    Public Sub clearcontrols()
        txtname.Text = ""
        txtaddr.Text = ""
        txtcontact.Text = ""
        txtweb.Text = ""
    End Sub
End Class
