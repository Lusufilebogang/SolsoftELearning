﻿
Partial Class admin_SalesPersonBook
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Protected Sub btndadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btndadd.Click

        Try
            Dim qry As String = "INSERT INTO SalespersonBook (SalesPersonID, BookID , BookName)  VALUES" _
                                        & "(@SPersonID, @BookID , @BookName)"
            Dim sqlcmd As New SqlCommand(qry, cn)
            sqlcmd.Parameters.Add("@SPersonID", SqlDbType.Int).Value = DDLSales.SelectedValue
            sqlcmd.Parameters.Add("@BookID", SqlDbType.Int).Value = DDLBook.SelectedValue
            sqlcmd.Parameters.Add("@BookName", SqlDbType.NVarChar).Value = DDLBook.SelectedItem.Text
            cn.Open()
            sqlcmd.ExecuteScalar()
            sqlcmd.Dispose()
            cn.Close()
            lblmsg.Text = "Book Added To Salesperson"
        Catch ex As Exception
            cn.Close()
            lblmsg.Text = "Not Added" & ex.Message
        End Try
    End Sub
End Class
