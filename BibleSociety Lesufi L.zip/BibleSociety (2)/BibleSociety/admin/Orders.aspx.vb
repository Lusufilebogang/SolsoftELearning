﻿
Partial Class admin_Orders
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            lbldate.Text = Date.Today
        End If
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        Dim OrderID As String
        OrderID = GridView1.SelectedRow.Cells(0).Text
        Response.Redirect("OrderDetails.aspx?Order=" + OrderID)
    End Sub

    Protected Sub GridView2_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView2.SelectedIndexChanged
        Dim OrderID As String
        OrderID = GridView2.SelectedRow.Cells(0).Text
        Response.Redirect("OrderDetails.aspx?Order=" + OrderID)
    End Sub
End Class
