﻿
Partial Class admin_authoredit
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        txtfname.Text = GridView1.SelectedRow.Cells(2).Text
        txtlname.Text = GridView1.SelectedRow.Cells(3).Text
        txtcell.Text = GridView1.SelectedRow.Cells(4).Text
        txteml.Text = GridView1.SelectedRow.Cells(5).Text
        txtaddr.Text = GridView1.SelectedRow.Cells(6).Text
    End Sub


    Protected Sub btnadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            Dim qry As String = "UPDATE Author SET FIrstName = @FName, LastName = @LName , CellNo = @CellNo, EmailAddress = @EmlAddr, Address = @Addr " & _
                                       "WHERE AuthorID = @AutID"
            Dim sqlcmd As New SqlCommand(qry, cn)
            sqlcmd.Parameters.Add("@FName", SqlDbType.NVarChar).Value = txtfname.Text
            sqlcmd.Parameters.Add("@LName", SqlDbType.NVarChar).Value = txtlname.Text
            sqlcmd.Parameters.Add("@CellNo", SqlDbType.NVarChar).Value = txtcell.Text
            sqlcmd.Parameters.Add("@EmlAddr", SqlDbType.NVarChar).Value = txteml.Text
            sqlcmd.Parameters.Add("@Addr", SqlDbType.NVarChar).Value = txtaddr.Text
            sqlcmd.Parameters.Add("@AutID", SqlDbType.Int).Value = GridView1.SelectedRow.Cells(1).Text
            cn.Open()
            sqlcmd.ExecuteScalar()
            sqlcmd.Dispose()
            cn.Close()
            clearcontrols()
            lblmsg.Text = "Record Updated"
            GridView1.DataBind()
        Catch ex As Exception
            cn.Close()
            lblmsg.Text = "Not Updated  " & ex.Message
        End Try
    End Sub

    Public Sub clearcontrols()
        txtfname.Text = ""
        txtlname.Text = ""
        txtcell.Text = ""
        txteml.Text = ""
        txtaddr.Text = ""
    End Sub
End Class
