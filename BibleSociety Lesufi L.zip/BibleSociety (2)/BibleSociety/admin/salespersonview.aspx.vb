﻿
Partial Class admin_salespersonview
    Inherits System.Web.UI.Page

End Class
