﻿
Partial Class admin_Publisheredit
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)


    Protected Sub btnadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Try
            Dim qry As String = "UPDATE Publisher SET PublisherName = @PubName , ContactNo = @ContNo ,Address = @Addr , Website = @Web " _
                                & " WHERE PublisherID = @PUBID"
            Dim sqlcmd As New SqlCommand(qry, cn)
            sqlcmd.Parameters.Add("@PubName", SqlDbType.NVarChar).Value = txtname.Text
            sqlcmd.Parameters.Add("@ContNo", SqlDbType.NVarChar).Value = txtcontact.Text
            sqlcmd.Parameters.Add("@Addr", SqlDbType.NVarChar).Value = txtaddr.Text
            sqlcmd.Parameters.Add("@Web", SqlDbType.NVarChar).Value = txtweb.Text
            sqlcmd.Parameters.Add("@PUBID", SqlDbType.Int).Value = GridView1.SelectedRow.Cells(1).Text
            cn.Open()
            sqlcmd.ExecuteScalar()
            sqlcmd.Dispose()
            cn.Close()
            lblmsg.Text = " Publisher Added Successfully "
            GridView1.DataBind()
        Catch ex As Exception
            cn.Close()
            lblmsg.Text = " Not Added  " & ex.Message
        End Try
    End Sub

    Public Sub clearcontrols()
        txtname.Text = ""
        txtaddr.Text = ""
        txtcontact.Text = ""
        txtweb.Text = ""
    End Sub
    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        txtname.Text = GridView1.SelectedRow.Cells(2).Text
        txtcontact.Text = GridView1.SelectedRow.Cells(3).Text
        txtaddr.Text = GridView1.SelectedRow.Cells(4).Text
        txtweb.Text = GridView1.SelectedRow.Cells(5).Text
    End Sub
End Class
