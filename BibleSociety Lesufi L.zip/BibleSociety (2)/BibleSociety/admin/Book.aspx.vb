﻿
Partial Class admin_Default
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)
    Protected Sub btnsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim FilePath As String = Server.MapPath("Images/")
        If FileUpload1.HasFile Then
            Dim picname As String
            Dim afile As String = FileUpload1.FileName
            FileUpload1.SaveAs(FilePath & "/" & FileUpload1.FileName)
            picname = afile
            Try
                Dim qry As String = "INSERT INTO Book (BookName, Year , Edition, Description , Publisher , Pages , Cover, Price, BookType ) VALUES " & _
                                    "(@BkNme, @Year , @Edi, @Descr , @Publ , @Pages , @Cov, @Prc, @BkTyp )"
                Dim sqlcmd As New SqlCommand(qry, cn)
                sqlcmd.Parameters.Add("@BKNme", SqlDbType.NVarChar).Value = txtnme.Text
                sqlcmd.Parameters.Add("@Year", SqlDbType.Int).Value = txtyear.Text
                sqlcmd.Parameters.Add("@Edi", SqlDbType.NVarChar).Value = txtedi.Text
                sqlcmd.Parameters.Add("@Descr", SqlDbType.NVarChar).Value = txtdesc.Text
                sqlcmd.Parameters.Add("@Publ", SqlDbType.Int).Value = DDLPub.SelectedValue
                sqlcmd.Parameters.Add("@Pages", SqlDbType.Int).Value = txtpages.Text
                sqlcmd.Parameters.Add("@Cov", SqlDbType.NVarChar).Value = CStr(picname)
                sqlcmd.Parameters.Add("@Prc", SqlDbType.Money).Value = txtprice.Text
                sqlcmd.Parameters.Add("@BkTyp", SqlDbType.NVarChar).Value = DropDownList1.SelectedValue
                cn.Open()
                sqlcmd.ExecuteScalar()
                sqlcmd.Dispose()
                cn.Close()
                lblmsg.Text = "Success"
                clearcontrols()
            Catch ex As Exception
                cn.Close()
                lblmsg.Text = "Failure " & ex.Message
            End Try

        End If
    End Sub

    Public Sub clearcontrols()
        txtnme.Text = ""
        txtyear.Text = ""
        txtedi.Text = ""
        txtdesc.Text = ""
        DDLPub.SelectedIndex = 0
        txtpages.Text = ""
        txtprice.Text = ""
        DropDownList1.SelectedIndex = 0

    End Sub
End Class
