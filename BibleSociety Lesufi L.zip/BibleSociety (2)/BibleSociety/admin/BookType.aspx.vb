﻿
Partial Class admin_BookType
    Inherits System.Web.UI.Page
    Dim constr As String = ConfigurationManager.ConnectionStrings("bbsociety").ToString
    Dim cn As New SqlConnection(constr)


    Protected Sub btnadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadd.Click
        If txtid.Text.Length = 5 Then
            Try
                Dim qry As String = "INSERT INTO BookType ( TypeID, TypeName , Description) " _
                                     & " VALUES (@TID, @TName , @Descr)"
                Dim sqlcmd As New SqlCommand(qry, cn)
                sqlcmd.Parameters.Add("@TID", SqlDbType.Char).Value = txtid.Text
                sqlcmd.Parameters.Add("@TName", SqlDbType.NVarChar).Value = txtname.Text
                sqlcmd.Parameters.Add("@Descr", SqlDbType.NVarChar).Value = txtdesc.Text
                cn.Open()
                sqlcmd.ExecuteScalar()
                sqlcmd.Dispose()
                cn.Close()
                lblmsg.Text = "Book Type Added Sucessfully"
                clearcontrols()
            Catch ex As Exception
                cn.Close()
                lblmsg.Text = "Not Added " & ex.Message
            End Try
        Else
            lblmsg.Text = "Type ID lenght can only be 5 Characters"
            txtid.Focus()
        End If

    End Sub

    Public Sub clearcontrols()
        txtname.Text = ""
        txtid.Text = ""
        txtdesc.Text = ""

    End Sub
End Class
